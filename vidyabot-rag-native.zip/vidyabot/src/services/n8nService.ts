/**
 * ==============================================================================
 * n8n Session-Complete Notifier (Background Automation Only)
 * ==============================================================================
 *
 * IMPORTANT: n8n is NEVER on the critical path here.
 * - It is fired AFTER the Post-Test Result page has already rendered
 *   using local data.
 * - The call is not awaited by any UI logic and has no effect on what
 *   the student sees.
 * - If the webhook is slow, unreachable, or misconfigured, this fails
 *   silently — the app behaves exactly as if n8n did not exist.
 *
 * Webhook URL resolution order:
 *   1. A URL saved at runtime via setWebhookUrl() (stored in localStorage) —
 *      lets you point at your self-hosted n8n instance without rebuilding.
 *   2. VITE_N8N_WEBHOOK_URL environment variable, if set at build time.
 *   3. Empty — the feature is simply skipped.
 * ==============================================================================
 */

export interface SessionCompletePayload {
  topicId: string;
  topicTitle: string;
  language: string;
  preTestPercentage: number | null;
  postTestPercentage: number;
  improvement: number | null;
  unresolvedErrorCount: number;
  timestamp: string;
}

export interface N8nTestResult {
  success: boolean;
  message: string;
}

const STORAGE_KEY_WEBHOOK = 'vidyabot_n8n_webhook_url';
const ENV_WEBHOOK_URL = import.meta.env.VITE_N8N_WEBHOOK_URL || '';
const REQUEST_TIMEOUT_MS = 3000; // cleans up the request if n8n hangs — never relied on by the UI

export const n8nService = {
  getWebhookUrl(): string {
    return localStorage.getItem(STORAGE_KEY_WEBHOOK) || ENV_WEBHOOK_URL || '';
  },

  setWebhookUrl(url: string) {
    localStorage.setItem(STORAGE_KEY_WEBHOOK, url.trim());
  },

  /**
   * Fire-and-forget: notify the n8n workflow that a learning session finished.
   * Never throws, never blocks, never awaited by the caller in a way that
   * affects rendering.
   */
  notifySessionComplete(payload: SessionCompletePayload): void {
    const webhookUrl = this.getWebhookUrl();
    if (!webhookUrl) {
      // No webhook configured — safe no-op, exactly as intended.
      return;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    })
      .catch((err) => {
        // Swallow all errors on purpose — logging only, never surfaced to the student.
        console.warn('[n8n] Session-complete notification failed (non-critical):', err);
      })
      .finally(() => clearTimeout(timeoutId));
  },

  /**
   * Used only by the settings modal to let you verify your self-hosted
   * webhook is reachable. This is a real network check (no fake success),
   * but it is still never called anywhere on the student-facing critical path.
   */
  async testConnection(): Promise<N8nTestResult> {
    const webhookUrl = this.getWebhookUrl();
    if (!webhookUrl) {
      return { success: false, message: 'No webhook URL configured yet.' };
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

      const res = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topicId: 'test',
          topicTitle: 'Connection Test',
          language: 'en',
          preTestPercentage: 40,
          postTestPercentage: 90,
          improvement: 50,
          unresolvedErrorCount: 0,
          timestamp: new Date().toISOString(),
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        return { success: true, message: `Webhook responded with ${res.status} OK.` };
      }
      return { success: false, message: `Webhook responded with status ${res.status}.` };
    } catch (err) {
      return { success: false, message: 'Could not reach the webhook (timed out or unreachable).' };
    }
  },
};
